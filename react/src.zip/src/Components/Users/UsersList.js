import React, {Component} from 'react';

class UsersList extends Component {
    render() {
        return (
            <div>
                Čia bus sąrašas visų naudotojų ir jų turimos grupės
            </div>
        );
    }
}

export default UsersList;