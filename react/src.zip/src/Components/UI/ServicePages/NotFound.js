import React from 'react';

const NotFound = () => {
    return (
        <div style={{'clear':'both'}} className="text-center">

            <h2>PUSLAPIS<br/>
            NERASTAS</h2>
            <h3>¯\_(ツ)_/¯</h3>

        </div>
    );
};

export default NotFound;
